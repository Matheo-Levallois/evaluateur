package demos.metier;

public class ExceptionValeurNonEntiere extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1111168471140140573L;

	public ExceptionValeurNonEntiere( String message) {
		super( message );		
	}
}
