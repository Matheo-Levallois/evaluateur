package demos.metier;

public class ExceptionValeurHorsBorne extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExceptionValeurHorsBorne( String message) {
		super( message );		
	}
}
